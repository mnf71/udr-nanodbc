## Environment

* nanodbc version:
* DBMS name/version:
* ODBC connection string:
* OS and Compiler:
* CMake settings:

## Actual behavior

## Expected  behavior

## Minimal Working Example
